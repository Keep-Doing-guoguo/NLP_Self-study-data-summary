from transformers import AutoTokenizer, AutoModelForMultipleChoice
import torch

# 加载预训练模型和分词器
model_name = "google/bert-base-multilingual-cased"#https://huggingface.co/bert-base-multilingual-cased
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForMultipleChoice.from_pretrained(model_name)

# 准备输入数据
question = "What is the capital of France?"
options = ["Paris", "London", "Berlin", "Madrid"]
input_text = f"{question} {options}"
input_encoding = tokenizer(input_text, return_tensors="pt")

# 进行预测
with torch.no_grad():
    outputs = model(**input_encoding)
    predictions = outputs.logits.argmax(dim=-1).tolist()[0]  # 提取正确答案的索引
    answer = options[predictions]  # 根据索引获取答案
    print("Answer:", answer)


'''
AutoModelForMultipleChoice是Hugging Face Transformers库中的一个预训练模型，用于多选题任务。该模型基于BERT架构，并针对文本进行了优化。
使用AutoModelForMultipleChoice模型可以方便地进行多选题任务，例如从多个选项中选择正确答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。
'''