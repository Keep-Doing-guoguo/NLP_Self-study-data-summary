from transformers import AutoModelForDepthEstimation, AutoTokenizer

model_name = 'Intel/dpt-large'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForDepthEstimation.from_pretrained(model_name)

print()


'''
AutoModelForDepthEstimation是一个基于视觉Transformer的模块，专门AutoModelForDepthEstimation是一个基于视觉Transformer的模块，专门用于处理单目深度估计任务。
单目深度估计是计算机视觉中的一个关键任务，它涉及从单个图像中预测场景的深度信息。这项任务的质量会受到问题的不适定性质和高质量数据集稀缺性的限制。
在使用AutoModelForDepthEstimation时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载'monodepth2'这个模型，可以这样调用：
'''


