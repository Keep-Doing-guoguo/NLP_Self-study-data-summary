from transformers import AutoConfig ,AutoModel # 导入包
from transformers import BertForSequenceClassification,AutoModelForSequenceClassification
path = r"D:\bert_base_chinese"  # 选择模型
path2 = r'D:\Pretrained_models-llama-2-7b-ms\modelscope\Llama-2-7b-chat-ms'
model = AutoModel.from_pretrained(path)#加载模型的两种方法1
# 或者
model1 = BertForSequenceClassification.from_pretrained(path)#这是一个专用类对于bert
model2 = AutoModelForSequenceClassification.from_pretrained(path)#这是一个通用类，用来做序列分类的，可以针对任何模型。只不过会在后面加上一个层结构。
# model3 = AutoModelForSequenceClassification.from_pretrained(path2)#在这里使用的是llama2-7b的模型来做的一个分类模型


model4 = ''

print()
'''
可以看到AutoModel是一个可以加载任何类（模型的最初始结构）的东西。而BertForSequenceClassification只可以加载Bert用来做分类。
而AutoModelForSequenceClassification可以加载任何模型用来做分类。
'''
























'''
1.AutoModel这是一个通用模型类，使用from_pretrained("model_name")或者from_config(config_class)方法创建，根据模型名称或者配置类实例自动创建一个模型实例。

2.BertForSequenceClassification与AutoModel不同的是，其具有序列分类头（原文是：with a sequence classification head）

3.AutoModelForSequenceClassification
BertForSequenceClassification 和 AutoModelForSequenceClassification 都是 Hugging Face Transformers 库中用于序列分类任务的模型类。

主要区别在于：

指定模型类型：BertForSequenceClassification 是特定于 BERT 架构的序列分类模型。它是在预训练的 BERT 模型之上添加了用于序列分类的分类头（顶层）。它是专门针对 BERT 架构而设计的。

通用性：AutoModelForSequenceClassification 是一个通用的模型类，它可以根据指定的预训练模型名称自动加载对应的模型架构，例如 BERT、RoBERTa、GPT 等，并在其之上添加一个用于序列分类的额外层。这使得它更加通用，可以适用于不同架构的模型。

因此，如果你确定要使用 BERT 模型进行序列分类任务，可以直接选择 BertForSequenceClassification。如果希望对不同的模型进行分类任务，可以使用 AutoModelForSequenceClassification 并在其中指定所需的模型名称。

4.AutoModelForMaskGeneration用于自动加载特定预训练模型架构以进行 Mask Generation（掩码生成）任务。你可以使用 BERT、RoBERTa、GPT 或其他模型进行 Mask Generation 任务。通用类的目的是为了让你能够方便地加载适合 Mask Generation 任务的不同预训练模型，并在其基础上进行进一步的微调或应用。

5.AutoModelForTextEncoding文本编码

6.AutoModelForPreTraining可以用于加载适用于预训练任务的模型。通常情况下，它用于加载预训练的Transformer模型，如BERT、GPT、RoBERTa等，这些模型可以应用于各种NLP任务，如文本生成、文本分类、问答等。

7.AutoModelForCausalLM 用于加载适用于因果语言模型（Causal Language Model，CLM）任务的预训练模型。CLM是一种生成式模型，通常用于生成下一个词或下一个句子，以便完成语言生成任务，如文本生成或对话系统。
这个类是一个通用的模型加载器，可以用于加载预训练的Transformer模型，例如GPT（Generative Pre-trained Transformer）。加载了这个类的模型可以应用于各种因果语言生成任务，如文本生成、对话生成等。您可以使用这个类来加载不同类型的预训练模型，并根据您的生成任务要求微调这些模型。

8.AutoModelForMaskedLM 是 Hugging Face Transformers 库中的一个类，用于加载适用于遮蔽语言建模（Masked Language Modeling，MLM）任务的预训练模型。MLM 是一种语言模型训练方式，通过对输入中的某些标记进行遮蔽（mask），然后尝试预测这些被遮蔽标记的正确词汇。
加载了这个类的模型可以应用于遮蔽语言建模任务，例如预测句子中被遮蔽的词汇或标记。

9.AutoModelForSeq2SeqLM 用于加载用于序列到序列学习（Sequence-to-Sequence Learning，Seq2Seq）任务的预训练模型。
Seq2Seq模型是一种神经网络架构，通常使用编码器-解码器结构，用于处理序列数据，如机器翻译、摘要生成、对话生成等任务。编码器将输入序列编码为一种中间表示形式，解码器将这种中间表示形式解码为目标序列。加载了这个类的模型可以用于生成文本、翻译、摘要等Seq2Seq任务。

10.AutoModelForQuestionAnswering 用于加载用于问答任务（Question Answering）的预训练模型。
这个类可以加载各种预训练的模型，如BERT、RoBERTa、DistilBERT等，用于对输入的问题和上下文进行理解，并提供相应的答案。在问答任务中，模型被训练用于理解给定的问题和相关的上下文，并尝试从上下文中找到正确的答案。加载了这个类的模型可以用于各种问答任务，如阅读理解、问题解答等。

11.AutoModelForTableQuestionAnswering用于表格问答任务。该模型基于BERT架构，并针对表格数据进行了优化。
使用AutoModelForTableQuestionAnswering模型可以方便地在表格数据上进行问答任务，例如从表格中提取答案或生成问题的答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。

12.AutoModelForVisualQuestionAnswering用于视觉问答任务。该模型基于BERT架构，并针对图像和问题进行了优化。
使用AutoModelForVisualQuestionAnswering模型可以方便地在图像上进行问答任务，例如从图像中提取答案或生成问题的答案。该模型支持多种输入格式，包括PIL图像、OpenCV图像和numpy数组等。

13.AutoModelForDocumentQuestionAnswering用于文档问答任务。该模型基于BERT架构，并针对长文本进行了优化。
使用AutoModelForDocumentQuestionAnswering模型可以方便地在长文本上进行问答任务，例如从文档中提取答案或生成问题的答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。

14.AutoModelForTokenClassification用于标记分类任务。该模型基于BERT架构，并针对文本进行了优化。
使用AutoModelForTokenClassification模型可以方便地进行标记分类任务，例如将文本中的每个单词标记为一个类别。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。

15.AutoModelForTokenClassification用于标记分类任务。该模型基于BERT架构，并针对文本进行了优化。
使用AutoModelForTokenClassification模型可以方便地进行标记分类任务，例如将文本中的每个单词标记为一个类别。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。

16.AutoModelForMultipleChoice是Hugging Face Transformers库中的一个预训练模型，用于多选题任务。该模型基于BERT架构，并针对文本进行了优化。
使用AutoModelForMultipleChoice模型可以方便地进行多选题任务，例如从多个选项中选择正确答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。

17.AutoModelForZeroShotImageClassification可用于零样本图像分类任务。该模型基于BERT架构，并针对图像进行了优化。
使用AutoModelForZeroShotImageClassification，您可以轻松地将图像分类为几个类别之一，而无需在训练过程中看到这些类别的示例。这是通过一种称为零样本学习的过程实现的，它涉及使用类别之间的语义关系进行预测。

18.AutoModelForImageSegmentation是Hugging Face Transformers库中的一个预训练模型，可用于图像分割任务。该模型基于BERT架构，并针对图像进行了优化。
使用AutoModelForImageSegmentation，您可以对图像进行语义分割，即将图像中的每个像素分类为几个类别之一。这对于自动驾驶、医学影像和目标检测等应用非常有用。

19.AutoModelForSemanticSegmentation是Hugging Face Transformers库中的一个预训练模型，可用于语义分割任务。该模型基于BERT架构，并针对图像进行了优化。
使用AutoModelForSemanticSegmentation，您可以对图像进行语义分割，即将图像中的每个像素分类为几个类别之一。这对于自动驾驶、医学影像和目标检测等应用非常有用。

20.AutoModelForUniversalSegmentation是Hugging Face Transformers库中的一个预训练模型，可用于通用分割任务。该模型基于BERT架构，并针对图像进行了优化。
使用AutoModelForUniversalSegmentation，您可以对图像进行语义分割，即将图像中的每个像素分类为几个类别之一。这对于自动驾驶、医学成像和对象检测等应用非常有用。

21.AutoModelForInstanceSegmentation是Hugging Face Transformers库中的一个预训练模型，可用于实例分割任务。该模型基于DETR架构，并针对图像进行了优化。
使用AutoModelForInstanceSegmentation，您可以对图像进行实例分割，即对图像中的每个对象实例进行分类并划定其边界。这对于自动驾驶、机器人和医学影像等应用非常有用。

22.AutoModelForObjectDetection是基于深度学习的物体检测算法，该算法可以在图片或视频中自动识别和定位物体。它由一系列卷积神经网络(CNN)组成，这些网络可以对图像进行特征提取和分类。
AutoModelForObjectDetection可以应用于各种场景，如安防监控、自动驾驶、医疗影像等。它具有高精度、高效率、可解释性好等优点，因此在近年来得到了广泛的应用和发展。

23.AutoModelForZeroShotObjectDetection是一种基于零样本学习的物体检测算法。这种算法的核心在于，即使面临未见过的类别，也能够进行准确的物体检测。
AutoModelForZeroShotObjectDetection在安防监控、自动驾驶、医疗影像等领域有着广泛的应用前景，尤其是在面对未知类别物体时，其优势更为明显。
然而，零样本学习相对于人脸任务是比较困难的，因为一般视觉Image中的场景、姿态、光照等变换比人脸情况复杂的多。

24.AutoModelForDepthEstimation是一种利用深度学习技术实现的深度估计模型。深度估计是指获取图像中场景里的每个点到相机的距离信息，这种距离信息组成的图我们称之为深度图。该模型采用视觉Transformer作为其骨干网络，以替代传统的卷积神经网络。
在具体应用中，例如"DistDepth"模型，它以每帧为基础推断深度，可以考虑引入视频的特性，为视频输入生成时域上更一致的深度。此外，单目深度估计是另一个重要应用，其目标是帮助计算机理解图像的深度，并预测每个像素的场景元素距离。
总的来说，AutoModelForDepthEstimation及其相关模型可以广泛应用于计算机视觉领域，如自动驾驶、无人机、机器人等领域，对于理解场景、避障等任务具有重要的作用。

25.AutoModelForVideoClassification是一个基于视觉Transformer的模型，用于处理和理解视频序列数据。这种模型可以对视频中的每个帧进行分类，从而理解整个视频的内容。
例如，在"MCG-NJU/videomae-base-finetuned-ssv2"这个模型中，就展示了如何使用预训练模型来理解视频内容。
此外，一些研究也提出了将VideoMAE扩展到十亿参数量级的预训练策略，其中包括了遮蔽编码器和解码器的输入标记等技术。这些策略有助于提高模型的性能和泛化能力。


26.AutoModelForVision2Seq是一个基于视觉Transformer的模型，主要用于处理和理解图像序列数据。
这种模型可以将图像序列转换为文本序列，从而理解和描述整个图像的内容。例如，它能够从一系列连续的图像中提取关键信息，然后生成一段描述这些图像内容的文本。
在实际应用中，你可以使用如"from_pretrained()"这样的方法来载入预训练模型并进行后续的处理。
这需要先安装Accelerate >= 0.9.0 和 PyTorch >= 1.9.0。同时，这种方法不需要创建整个模型，然后再加载预训练权重，因此可以节省大量的内存。


27.AutoModelForAudioClassification是一个基于Transformers库的模块，专门AutoModelForAudioClassification是一个基于Transformers库的模块，专门用于加载预训练模型以处理音频分类任务。
音频分类即是给音频数据分配一个标签或类别。
这个任务在很多场景中都有实际应用，例如识别声音的意图、区分不同的说话人，甚至可以通过动物的叫声来识别其物种。
在使用AutoModelForAudioClassification时，需要传入一个字符串参数，表示要加载的模型名称。
例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：

28.AutoModelForCTC是一个加载预训练模型的模块，它属于transformers库。该模块主要用于处理序列标注问题，如语音识别等。
在具体使用时，根据传入的模型名称，AutoModelForCTC可以自动选择对应的模型，并将模型加载为可以直接使用的对象。

其中，CTC（Connectionist Temporal Classification）是一种损失函数，常用于处理序列标注问题。与传统的序列标注算法不同，CTC不需要每一时刻输入与输出符号完全对齐。
相反，CTC通过扩展标签集合并添加空元素来解决这个问题。
在使用扩展标签集合对序列进行标注后，所有可以通过映射函数转换为真实序列的预测序列，都被视为正确的预测结果。
因此，CTC可以在无需数据对齐处理的情况下得到预测序列。

29.AutoModelForSpeechSeq2Seq是一个基于Transformers库的模块，用于加载预训练模型。该模块主要用于处理序列到序列（seq2seq）的问题，如语音识别、机器翻译等。

在使用AutoModelForSpeechSeq2Seq时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：


30.AutoModelForAudioFrameClassification是一个基于Transformers库的模块，用于加载预训练模型。该模块主要用于处理音频帧分类问题，如语音识别、音乐分类等。
在使用AutoModelForAudioFrameClassification时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：

31.AutoModelForAudioXVector是一个基于Transformers库的模块，用于加载预训练模型。
这个模块专门处理音频检索任务，通过x-vector头部进行模型实例化。
在使用时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：

32.AutoModelForAudioClassification是一个基于Transformers库的模块，专门AutoModelForAudioClassification是一个基于Transformers库的模块，专门用于加载预训练模型以处理音频分类任务。
音频分类即是给音频数据分配一个标签或类别。这个任务在很多场景中都有实际应用，例如识别声音的意图、区分不同的说话人，甚至可以通过动物的叫声来识别其物种。
在使用AutoModelForAudioClassification时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：

33.AutoModelForVideoClassification是一个基于Transformers库的模块，专门AutoModelForVideoClassification是一个基于Transformers库的模块，专门用于加载预训练模型以处理视频分类任务。
视频分类即是给视频数据分配一个标签或类别。这个任务在很多场景中都有实际应用，例如识别视频的内容、行为或者事件等。
在使用AutoModelForVideoClassification时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载'MCG-NJU/videomae-base-finetuned-ssv2'这个模型，可以这样调用：

34.AutoModelForDepthEstimation是一个基于视觉Transformer的模块，专门AutoModelForDepthEstimation是一个基于视觉Transformer的模块，专门用于处理单目深度估计任务。
单目深度估计是计算机视觉中的一个关键任务，它涉及从单个图像中预测场景的深度信息。这项任务的质量会受到问题的不适定性质和高质量数据集稀缺性的限制。
在使用AutoModelForDepthEstimation时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载'monodepth2'这个模型，可以这样调用：

35.AutoModelForZeroShotObjectDetection是一个基于视觉Transformer的模块，专门用于处理零样本目标检测任务。
零样本目标检测是指在没有见过某个类别的情况下，仍然能够识别该类别的目标。这项任务在实际应用中具有很大的挑战性，因为需要解决类别之间的语义鸿沟问题。
在使用AutoModelForZeroShotObjectDetection时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载'facebook/detr-resnet-50'这个模型，可以这样调用：

36.

37.

38.

39.

40.

41.

42.










reference
https://zhuanlan.zhihu.com/p/643472969
'''