from transformers import AutoModelWithLMHead, AutoTokenizer

model_name = 'distilbert-base-cased # Example checkpoint'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelWithLMHead.from_pretrained(model_name)
'''
AutoModelWithLMHead是一个基于视觉Transformer的模块，它是一个用于语言模型任务的通用模型类。
当使用AutoModelWithLMHead.from_pretrained(pretrained_model_name_or_path)方法创建该模型时，它会被实例化为库中的语言模型模型类之一。

在使用AutoModelWithLMHead时，需要传入一个字符串参数，表示要加载的预训练模型的名称或路径。例如，如果要加载'distilbert-base-cased'这个模型，可以这样调用：
'''