from transformers import AutoTokenizer, AutoModelForUniversalSegmentation
import torch

# 加载预训练模型和分词器
model_name = "google/ai-designer/segmentation/mobilenetv2-seg-finetuned-coco17std"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForUniversalSegmentation.from_pretrained(model_name)

# 准备输入数据
image_path = "example.jpg"  # 您的图像文件路径
input_text = f"一张{label}的照片。"  # 要预测的标签（例如，“狗”）
input_encoding = tokenizer(input_text, return_tensors="pt")

# 执行推理
with torch.no_grad():
    outputs = model(**input_encoding)
    answer = outputs[0].argmax(dim=1).squeeze().item()  # 获取预测的类别索引
    print("Answer:", answer)
'''
在此示例中，我们首先从Hugging Face Model Hub加载预训练的AutoModelForUniversalSegmentation模型和分词器。
然后，我们通过提供图像文件路径和要预测的标签（例如，“狗”）来准备输入数据。
最后，我们通过将输入编码传递给模型并从输出日志中提取预测的类别索引来执行推理。
'''