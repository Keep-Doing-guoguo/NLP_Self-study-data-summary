from transformers import AutoTokenizer, AutoModelForVisualQuestionAnswering
import torch
from PIL import Image

# 加载预训练模型和分词器
model_name = "visualbert-vqa"#https://huggingface.co/uclanlp/visualbert-vqa
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForVisualQuestionAnswering.from_pretrained(model_name)

# 准备输入数据
image_path = "example.jpg"  # 图像路径
question = "What is the color of the sky?"  # 问题

# 读取图像并转换为张量
image = Image.open(image_path).convert("RGB")
image_tensor = torch.unsqueeze(torch.from_numpy(image), 0)

# 准备输出数据
answer_start_logits = torch.tensor([0]).unsqueeze(0)  # 假设我们要预测第一个答案
answer_end_logits = torch.tensor([0]).unsqueeze(0)  # 假设我们要预测最后一个答案
output_ids = torch.cat((answer_start_logits, answer_end_logits)).unsqueeze(0)
output_encoding = {"input_ids": output_ids}

# 进行预测
with torch.no_grad():
    outputs = model(**image_tensor, **output_encoding)
    answer_start_index = torch.argmax(outputs.logits[0][:, 1:]) + 1
    answer_end_index = torch.argmax(outputs.logits[1][:, :-1]) + 1
    answer = tokenizer.convert_tokens_to_string(tokenizer.convert_ids_to_tokens(output_ids[0][answer_start_index:answer_end_index]))
    print("Answer:", answer)


'''
AutoModelForVisualQuestionAnswering用于视觉问答任务。
该模型基于BERT架构，并针对图像和问题进行了优化。
使用AutoModelForVisualQuestionAnswering模型可以方便地在图像上进行问答任务，例如从图像中提取答案或生成问题的答案。
该模型支持多种输入格式，包括PIL图像、OpenCV图像和numpy数组等。
'''