from transformers import AutoModelForAudioFrameClassification, AutoFeatureExtractor

model_name = "facebook/wav2vec2-base-960h"
model_name = r"D:\Code Downloads\facebookwav2vec2-base-960h"
feature_extractor = AutoFeatureExtractor.from_pretrained(model_name)
model = AutoModelForAudioFrameClassification.from_pretrained(model_name)


print()

'''
AutoModelForAudioFrameClassification是一个基于Transformers库的模块，用于加载预训练模型。
该模块主要用于处理音频帧分类问题，如语音识别、音乐分类等。
在使用AutoModelForAudioFrameClassification时，需要传入一个字符串参数，表示要加载的模型名称。
例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：
'''