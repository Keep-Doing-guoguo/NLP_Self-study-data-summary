from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

model_name = "facebook/wav2vec2-base-960h"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

'''
AutoModelForSeq2SeqLM 用于加载用于序列到序列学习（Sequence-to-Sequence Learning，Seq2Seq）任务的预训练模型。
Seq2Seq模型是一种神经网络架构，通常使用编码器-解码器结构，用于处理序列数据，如机器翻译、摘要生成、对话生成等任务。
编码器将输入序列编码为一种中间表示形式，解码器将这种中间表示形式解码为目标序列。加载了这个类的模型可以用于生成文本、翻译、摘要等Seq2Seq任务。
'''
