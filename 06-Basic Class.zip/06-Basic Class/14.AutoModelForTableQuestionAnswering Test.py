from transformers import AutoTokenizer, AutoModelForTableQuestionAnswering
import torch

# 加载预训练模型和分词器https://huggingface.co/tiennvcs/layoutlmv2-base-uncased-finetuned-docvqa
model_name = "microsoft/tableqa-base-uncased-new"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTableQuestionAnswering.from_pretrained(model_name)

# 准备输入数据
input_text = "What is the capital of France?"
input_encoding = tokenizer(input_text, return_tensors="pt")

# 准备输出数据
output_ids = torch.tensor([0]).unsqueeze(0)  # 假设我们要预测第一个答案
output_encoding = {"input_ids": output_ids}


# 进行预测
with torch.no_grad():
    outputs = model(**input_encoding, **output_encoding)
    answer_start_logits = outputs.logits[0][:, 1:]
    answer_end_logits = outputs.logits[1][:, :-1]
    answer_start_index = torch.argmax(answer_start_logits)
    answer_end_index = torch.argmax(answer_end_logits) + 1
    answer = tokenizer.convert_tokens_to_string(tokenizer.convert_ids_to_tokens(input_ids[0][answer_start_index:answer_end_index]))
    print("Answer:", answer)


'''
AutoModelForTableQuestionAnswering用于表格问答任务。该模型基于BERT架构，并针对表格数据进行了优化。
使用AutoModelForTableQuestionAnswering模型可以方便地在表格数据上进行问答任务，例如从表格中提取答案或生成问题的答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。
'''