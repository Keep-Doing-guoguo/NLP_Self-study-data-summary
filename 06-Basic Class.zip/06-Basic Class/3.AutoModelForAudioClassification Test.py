from transformers import AutoModelForAudioClassification, AutoTokenizer

model_name = r"D:\Code Downloads\facebookwav2vec2-base-960h"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForAudioClassification.from_pretrained(model_name)
print()

'''
AutoModelForAudioClassification是一个基于Transformers库的模块，专门AutoModelForAudioClassification是一个基于Transformers库的模块，专门用于加载预训练模型以处理音频分类任务。
音频分类即是给音频数据分配一个标签或类别。
这个任务在很多场景中都有实际应用，例如识别声音的意图、区分不同的说话人，甚至可以通过动物的叫声来识别其物种。
在使用AutoModelForAudioClassification时，需要传入一个字符串参数，表示要加载的模型名称。
例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：
'''