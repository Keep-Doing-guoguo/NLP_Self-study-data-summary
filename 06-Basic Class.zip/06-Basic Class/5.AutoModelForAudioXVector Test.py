from transformers import AutoModelForAudioXVector, AutoFeatureExtractor

model_name = "facebook/wav2vec2-base-960h"
model_name = r"D:\Code Downloads\facebookwav2vec2-base-960h"
feature_extractor = AutoFeatureExtractor.from_pretrained(model_name)
model = AutoModelForAudioXVector.from_pretrained(model_name)


print()


'''
AutoModelForAudioXVector是一个基于Transformers库的模块，用于加载预训练模型。
这个模块专门处理音频检索任务，通过x-vector头部进行模型实例化。
在使用时，需要传入一个字符串参数，表示要加载的模型名称。
例如，如果要加载"facebook/wav2vec2-base-960h"这个模型，可以这样调用：
'''
'''
Wav2Vec2ForXVector(
  (wav2vec2): Wav2Vec2Model(
    (feature_extractor): Wav2Vec2FeatureEncoder(
      (conv_layers): ModuleList(
        (0): Wav2Vec2GroupNormConvLayer(
          (conv): Conv1d(1, 512, kernel_size=(10,), stride=(5,), bias=False)
          (activation): GELUActivation()
          (layer_norm): GroupNorm(512, 512, eps=1e-05, affine=True)
        )
        (1-4): 4 x Wav2Vec2NoLayerNormConvLayer(
          (conv): Conv1d(512, 512, kernel_size=(3,), stride=(2,), bias=False)
          (activation): GELUActivation()
        )
        (5-6): 2 x Wav2Vec2NoLayerNormConvLayer(
          (conv): Conv1d(512, 512, kernel_size=(2,), stride=(2,), bias=False)
          (activation): GELUActivation()
        )
      )
    )
    (feature_projection): Wav2Vec2FeatureProjection(
      (layer_norm): LayerNorm((512,), eps=1e-05, elementwise_affine=True)
      (projection): Linear(in_features=512, out_features=768, bias=True)
      (dropout): Dropout(p=0.1, inplace=False)
    )
    (encoder): Wav2Vec2Encoder(
      (pos_conv_embed): Wav2Vec2PositionalConvEmbedding(
        (conv): Conv1d(768, 768, kernel_size=(128,), stride=(1,), padding=(64,), groups=16)
        (padding): Wav2Vec2SamePadLayer()
        (activation): GELUActivation()
      )
      (layer_norm): LayerNorm((768,), eps=1e-05, elementwise_affine=True)
      (dropout): Dropout(p=0.1, inplace=False)
      (layers): ModuleList(
        (0-11): 12 x Wav2Vec2EncoderLayer(
          (attention): Wav2Vec2Attention(
            (k_proj): Linear(in_features=768, out_features=768, bias=True)
            (v_proj): Linear(in_features=768, out_features=768, bias=True)
            (q_proj): Linear(in_features=768, out_features=768, bias=True)
            (out_proj): Linear(in_features=768, out_features=768, bias=True)
          )
          (dropout): Dropout(p=0.1, inplace=False)
          (layer_norm): LayerNorm((768,), eps=1e-05, elementwise_affine=True)
          (feed_forward): Wav2Vec2FeedForward(
            (intermediate_dropout): Dropout(p=0.1, inplace=False)
            (intermediate_dense): Linear(in_features=768, out_features=3072, bias=True)
            (intermediate_act_fn): GELUActivation()
            (output_dense): Linear(in_features=3072, out_features=768, bias=True)
            (output_dropout): Dropout(p=0.1, inplace=False)
          )
          (final_layer_norm): LayerNorm((768,), eps=1e-05, elementwise_affine=True)
        )
      )
    )
  )
  (projector): Linear(in_features=768, out_features=512, bias=True)
  (tdnn): ModuleList(
    (0): TDNNLayer(
      (kernel): Linear(in_features=2560, out_features=512, bias=True)
      (activation): ReLU()
    )
    (1-2): 2 x TDNNLayer(
      (kernel): Linear(in_features=1536, out_features=512, bias=True)
      (activation): ReLU()
    )
    (3): TDNNLayer(
      (kernel): Linear(in_features=512, out_features=512, bias=True)
      (activation): ReLU()
    )
    (4): TDNNLayer(
      (kernel): Linear(in_features=512, out_features=1500, bias=True)
      (activation): ReLU()
    )
  )
  (feature_extractor): Linear(in_features=3000, out_features=512, bias=True)
  (classifier): Linear(in_features=512, out_features=512, bias=True)
  (objective): AMSoftmaxLoss(
    (loss): CrossEntropyLoss()
  )
)
'''