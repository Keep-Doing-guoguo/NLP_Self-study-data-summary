from transformers import AutoModelForVideoClassification, AutoTokenizer

model_name = 'MCG-NJU/videomae-base-finetuned-ssv2 #Example checkpoint'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForVideoClassification.from_pretrained(model_name, load_in_8bit=True, device_map='auto')

'''
AutoModelForVideoClassification是一个基于视觉Transformer的模型，用于处理和理解视频序列数据。
这种模型可以对视频中的每个帧进行分类，从而理解整个视频的内容。
例如，在"MCG-NJUideomae-base-finetuned-ssv2"这个模型中，就展示了如何使用预训练模型来理解视频内容。
此外，一些研究也提出了将VideoMAE扩展到十亿参数量级的预训练策略，其中包括了遮蔽编码器和解码器的输入标记等技术。
这些策略有助于提高模型的性能和泛化能力。
'''