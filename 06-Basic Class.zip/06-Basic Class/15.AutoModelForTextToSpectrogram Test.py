from transformers import AutoModelForTextToSpectrogram, AutoTokenizer

model_name = 'facebook/wav2vec2-base-960h # Example checkpoint'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTextToSpectrogram.from_pretrained(model_name)
