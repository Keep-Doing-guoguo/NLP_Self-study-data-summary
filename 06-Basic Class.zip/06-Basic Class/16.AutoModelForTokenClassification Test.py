from transformers import AutoTokenizer, AutoModelForTokenClassification
import torch

# 加载预训练模型和分词器
model_name = "dbmdz/bert-large-cased-finetuned-conll03-english"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# 准备输入数据
text = "This is an example sentence."
input_encoding = tokenizer(text, return_tensors="pt")

# 进行预测
with torch.no_grad():
    outputs = model(**input_encoding)
    predictions = outputs.logits.argmax(dim=-1).tolist()[1:-1]  # 提取每个单词的标签
    print("Predictions:", predictions)
'''
AutoModelForTokenClassification用于标记分类任务。
该模型基于BERT架构，并针对文本进行了优化。
使用AutoModelForTokenClassification模型可以方便地进行标记分类任务，例如将文本中的每个单词标记为一个类别。
该模型支持多种输入格式，包括纯文本、Markdown和HTML等。
'''