from transformers import AutoModelForMaskedImageModeling, AutoTokenizer

model_name = r'D:\Code Downloads\facebookdeit-base-distillation-0.1' # Example checkpoint

model = AutoModelForMaskedImageModeling.from_pretrained(model_name)

print()
'''
AutoModelForMaskedImageModeling是一个基于视觉Transformer的模块，专门AutoModelForMaskedImageModeling是一个基于视觉Transformer的模块，专门用于处理遮盖图像建模任务。
这项任务借鉴了预训练语言模型BERT采用的自掩码预训练机制，即对需要进行预训练的图像输入进行随机的部分遮盖，从而实现对于图像数据的预训练。

在使用AutoModelForMaskedImageModeling时，需要传入一个字符串参数，表示要加载的模型名称。例如，如果要加载'facebook/deit-base-distillation-0.1'这个模型，可以这样调用：
'''

'''
视觉模型是不需要tokenizer的
DeiTForMaskedImageModeling(
  (deit): DeiTModel(
    (embeddings): DeiTEmbeddings(
      (patch_embeddings): DeiTPatchEmbeddings(
        (projection): Conv2d(3, 768, kernel_size=(16, 16), stride=(16, 16))
      )
      (dropout): Dropout(p=0.0, inplace=False)
    )
    (encoder): DeiTEncoder(
      (layer): ModuleList(
        (0-11): 12 x DeiTLayer(
          (attention): DeiTAttention(
            (attention): DeiTSelfAttention(
              (query): Linear(in_features=768, out_features=768, bias=True)
              (key): Linear(in_features=768, out_features=768, bias=True)
              (value): Linear(in_features=768, out_features=768, bias=True)
              (dropout): Dropout(p=0.0, inplace=False)
            )
            (output): DeiTSelfOutput(
              (dense): Linear(in_features=768, out_features=768, bias=True)
              (dropout): Dropout(p=0.0, inplace=False)
            )
          )
          (intermediate): DeiTIntermediate(
            (dense): Linear(in_features=768, out_features=3072, bias=True)
            (intermediate_act_fn): GELUActivation()
          )
          (output): DeiTOutput(
            (dense): Linear(in_features=3072, out_features=768, bias=True)
            (dropout): Dropout(p=0.0, inplace=False)
          )
          (layernorm_before): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
          (layernorm_after): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
        )
      )
    )
    (layernorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
  )
  (decoder): Sequential(
    (0): Conv2d(768, 768, kernel_size=(1, 1), stride=(1, 1))
    (1): PixelShuffle(upscale_factor=16)
  )
)
'''