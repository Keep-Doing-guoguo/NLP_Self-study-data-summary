
from transformers import AutoConfig, AutoModelForDocumentQuestionAnswering

# Download model and configuration from huggingface.co and cache.
model = AutoModelForDocumentQuestionAnswering.from_pretrained("impira/layoutlm-document-qa", revision="52e01b3")

# Update configuration during loading
model = AutoModelForDocumentQuestionAnswering.from_pretrained("impira/layoutlm-document-qa", revision="52e01b3", output_attentions=True)
model.config.output_attentions

# Loading from a TF checkpoint file instead of a PyTorch model (slower)
config = AutoConfig.from_pretrained("./tf_model/layoutlm_tf_model_config.json")
model = AutoModelForDocumentQuestionAnswering.from_pretrained(
    "./tf_model/layoutlm_tf_checkpoint.ckpt.index", from_tf=True, config=config
)
'''
AutoModelForDocumentQuestionAnswering用于文档问答任务。该模型基于BERT架构，并针对长文本进行了优化。
使用AutoModelForDocumentQuestionAnswering模型可以方便地在长文本上进行问答任务，例如从文档中提取答案或生成问题的答案。该模型支持多种输入格式，包括纯文本、Markdown和HTML等。
'''